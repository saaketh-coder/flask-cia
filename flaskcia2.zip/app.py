from flask import Flask, render_template, request, redirect, url_for
import pymysql
import pickle
app = Flask(__name__,template_folder='./',static_folder='./', static_url_path='')
app.secret_key = 'super secret key'

with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

# Database connection details
HOST = 'localhost'
USER = 'root'
PASSWORD = 'Saaketh@03'
DB_NAME = 'flask_login'

# Home page
@app.route('/')
def index():
    return render_template('index.html')

# Login page
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    connection = pymysql.connect(host=HOST, user=USER, password=PASSWORD, database=DB_NAME)
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM accounts WHERE username=%s AND password=%s', (username, password))
    user = cursor.fetchone()
    if user:
        return redirect(url_for('success'))
    else:
        error = 'Invalid username or password'
        return render_template('index.html', error=error)

# Success page
@app.route('/success')
def success():
    return render_template('success.html')

# Prediction page
@app.route('/predict', methods=['POST'])
def prediction():
    FoundingYear = float(request.form['Founding Year'])
    AnnualRevenue(USD Billions) = float(request.form['Annual Revenue 2022-2023 (USD in Billions)'])
    MarketCap = float(request.form['Market Cap (USD in Trillions)'])
    AnnualIncomeTax= float(request.form['Annual Income Tax in 2022-2023 (USD in Billions)'])

    values = [ FoundingYear,AnnualRevenue(USD Billions),MarketCap ,AnnualIncomeTax]

    result = model.predict([values])

   

    return render_template('result.html', result=result)

if __name__ == '__main__':
    app.run(host='localhost',port=5000,debug=True)
    