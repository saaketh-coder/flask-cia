CREATE DATABASE flask_login;
USE flask_login;



CREATE TABLE Accounts ( 
username varchar(50) NOT NULL,
password varchar(255) NOT NULL
);

INSERT INTO Accounts VALUES ("Saaketh123","Saaketh03"),("Surya123","Surya03"),("Test","Test123");
SELECT *FROM Accounts;